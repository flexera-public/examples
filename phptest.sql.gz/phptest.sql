CREATE DATABASE phptestdb;
USE phptestdb;

CREATE TABLE  `phptest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO phptest(name,value) VALUES('phptest1','I am in the db');
INSERT INTO phptest(name,value) VALUES('phptest2','I am in the db');
INSERT INTO phptest(name,value) VALUES('phptest3','I am in the db');
