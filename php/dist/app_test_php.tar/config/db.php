<?php
//DataBase Connect Infomation
$hostname_DB = "localhost";
$database_DB = "app_test";
$username_DB = "app_user";
$password_DB = "app_password";
?>
