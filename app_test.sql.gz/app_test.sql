<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  
  


  

  <head>
    <title>
      /unified_test_app/common/sql/app_test.sql – RightScale
    </title>
        <link rel="search" href="/trac/rightscale/search" />
        <link rel="help" href="/trac/rightscale/wiki/TracGuide" />
        <link rel="alternate" href="/trac/rightscale/browser/unified_test_app/common/sql/app_test.sql?format=txt" type="text/plain" title="Plain Text" /><link rel="alternate" href="/trac/rightscale/export/10588/unified_test_app/common/sql/app_test.sql" type="text/x-sql; charset=iso-8859-15" title="Original Format" />
        <link rel="up" href="/trac/rightscale/browser/unified_test_app/common/sql" title="Parent directory" />
        <link rel="start" href="/trac/rightscale/wiki" />
        <link rel="stylesheet" href="/trac/rightscale/chrome/common/css/trac.css" type="text/css" /><link rel="stylesheet" href="/trac/rightscale/chrome/common/css/code.css" type="text/css" /><link rel="stylesheet" href="/trac/rightscale/pygments/trac.css" type="text/css" /><link rel="stylesheet" href="/trac/rightscale/chrome/common/css/browser.css" type="text/css" />
        <link rel="shortcut icon" href="/trac/rightscale/chrome/common/trac.ico" type="image/x-icon" />
        <link rel="icon" href="/trac/rightscale/chrome/common/trac.ico" type="image/x-icon" />
      <link type="application/opensearchdescription+xml" rel="search" href="/trac/rightscale/search/opensearch" title="Search RightScale" />
    <script type="text/javascript" src="/trac/rightscale/chrome/common/js/jquery.js"></script><script type="text/javascript" src="/trac/rightscale/chrome/common/js/trac.js"></script><script type="text/javascript" src="/trac/rightscale/chrome/common/js/search.js"></script>
    <!--[if lt IE 7]>
    <script type="text/javascript" src="/trac/rightscale/chrome/common/js/ie_pre7_hacks.js"></script>
    <![endif]-->
    <script type="text/javascript">
      jQuery(document).ready(function($) {
        $(".trac-toggledeleted").show().click(function() {
                  $(this).siblings().find(".trac-deleted").toggle();
                  return false;
        }).click();
        $("#jumploc input").hide();
        $("#jumploc select").change(function () {
          this.parentNode.parentNode.submit();
        });
      });
    </script>
  </head>
  <body>
    <div id="banner">
      <div id="header">
        <a id="logo" href="https://wush.net/trac/rightscale/"><img src="/~rightscale/rightscale_logo.png" alt="Trac" height="26" width="208" /></a>
      </div>
      <form id="search" action="/trac/rightscale/search" method="get">
        <div>
          <label for="proj-search">Search:</label>
          <input type="text" id="proj-search" name="q" size="18" value="" />
          <input type="submit" value="Search" />
        </div>
      </form>
      <div id="metanav" class="nav">
    <ul>
      <li class="first">logged in as erik</li><li><a href="/trac/rightscale/logout" onclick="clearAuthenticationCache('/trac/rightscale/logout')">Logout</a></li><li><a href="/trac/rightscale/wiki/TracGuide">Help/Guide</a></li><li><a href="/trac/rightscale/about">About Trac</a></li><li class="last"><a href="/trac/rightscale/prefs">Preferences</a></li>
    </ul>
  </div>
    </div>
    <div id="mainnav" class="nav">
    <ul>
      <li class="first"><a href="/trac/rightscale/wiki">Wiki</a></li><li><a href="/trac/rightscale/timeline">Timeline</a></li><li><a href="/trac/rightscale/roadmap">Roadmap</a></li><li class="active"><a href="/trac/rightscale/browser">Browse Source</a></li><li><a href="/trac/rightscale/report">View Tickets</a></li><li><a href="/trac/rightscale/newticket">New Ticket</a></li><li class="last"><a href="/trac/rightscale/search">Search</a></li>
    </ul>
  </div>
    <div id="main">
      <div id="ctxtnav" class="nav">
        <h2>Context Navigation</h2>
          <ul>
              <li class="first"><a href="/trac/rightscale/changeset/8908/unified_test_app/sql/app_test.sql">Last Change</a></li><li><a href="/trac/rightscale/browser/unified_test_app/sql/app_test.sql?annotate=blame&amp;rev=8908" title="Annotate each line with the last changed revision (this can be time consuming...)">Annotate</a></li><li class="last"><a href="/trac/rightscale/log/unified_test_app/common/sql/app_test.sql">Revision Log</a></li>
          </ul>
        <hr />
      </div>
    <div id="content" class="browser">
      <h1>
    <a class="pathentry first" title="Go to root directory" href="/trac/rightscale/browser">root</a><span class="pathentry sep">/</span><a class="pathentry" title="View unified_test_app" href="/trac/rightscale/browser/unified_test_app">unified_test_app</a><span class="pathentry sep">/</span><a class="pathentry" title="View common" href="/trac/rightscale/browser/unified_test_app/common">common</a><span class="pathentry sep">/</span><a class="pathentry" title="View sql" href="/trac/rightscale/browser/unified_test_app/common/sql">sql</a><span class="pathentry sep">/</span><a class="pathentry" title="View app_test.sql" href="/trac/rightscale/browser/unified_test_app/common/sql/app_test.sql">app_test.sql</a>
    <br style="clear: both" />
  </h1>
      <div id="jumprev">
        <form action="" method="get">
          <div>
            <label for="rev">
              View revision:</label>
            <input type="text" id="rev" name="rev" size="6" />
          </div>
        </form>
      </div>
      <table id="info" summary="Revision info">
        <tr>
          <th scope="col">
            Revision <a href="/trac/rightscale/changeset/8908">8908</a>, <span title="1977 bytes">1.9 KB</span>
            (checked in by cary, <a class="timeline" href="/trac/rightscale/timeline?from=2010-01-22T14%3A16%3A26-0600&amp;precision=second" title="2010-01-22T14:16:26-0600 in Timeline">15 months</a> ago)
          </th>
        </tr>
        <tr>
          <td class="message searchable">
              <p>
added php and unified schema dump<br />
</p>
          </td>
        </tr>
      </table>
      <div id="preview" class="searchable">
    <table class="code"><thead><tr><th class="lineno" title="Line numbers">Line</th><th class="content"> </th></tr></thead><tbody><tr><th id="L1"><a href="#L1">1</a></th><td><span class="c1">-- MySQL dump 10.11</span></td></tr><tr><th id="L2"><a href="#L2">2</a></th><td><span class="c1">--</span></td></tr><tr><th id="L3"><a href="#L3">3</a></th><td><span class="c1">-- Host: localhost    Database: app_test</span></td></tr><tr><th id="L4"><a href="#L4">4</a></th><td><span class="c1">-- ------------------------------------------------------</span></td></tr><tr><th id="L5"><a href="#L5">5</a></th><td><span class="c1">-- Server version       5.0.45-log</span></td></tr><tr><th id="L6"><a href="#L6">6</a></th><td><span class="c1"></span></td></tr><tr><th id="L7"><a href="#L7">7</a></th><td><span class="cm">/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */</span><span class="p">;</span></td></tr><tr><th id="L8"><a href="#L8">8</a></th><td><span class="cm">/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */</span><span class="p">;</span></td></tr><tr><th id="L9"><a href="#L9">9</a></th><td><span class="cm">/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */</span><span class="p">;</span></td></tr><tr><th id="L10"><a href="#L10">10</a></th><td><span class="cm">/*!40101 SET NAMES utf8 */</span><span class="p">;</span></td></tr><tr><th id="L11"><a href="#L11">11</a></th><td><span class="cm">/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */</span><span class="p">;</span></td></tr><tr><th id="L12"><a href="#L12">12</a></th><td><span class="cm">/*!40103 SET TIME_ZONE='+00:00' */</span><span class="p">;</span></td></tr><tr><th id="L13"><a href="#L13">13</a></th><td><span class="cm">/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */</span><span class="p">;</span></td></tr><tr><th id="L14"><a href="#L14">14</a></th><td><span class="cm">/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */</span><span class="p">;</span></td></tr><tr><th id="L15"><a href="#L15">15</a></th><td><span class="cm">/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */</span><span class="p">;</span></td></tr><tr><th id="L16"><a href="#L16">16</a></th><td><span class="cm">/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */</span><span class="p">;</span></td></tr><tr><th id="L17"><a href="#L17">17</a></th><td></td></tr><tr><th id="L18"><a href="#L18">18</a></th><td><span class="c1">--</span></td></tr><tr><th id="L19"><a href="#L19">19</a></th><td><span class="c1">-- Current Database: `app_test`</span></td></tr><tr><th id="L20"><a href="#L20">20</a></th><td><span class="c1">--</span></td></tr><tr><th id="L21"><a href="#L21">21</a></th><td><span class="c1"></span></td></tr><tr><th id="L22"><a href="#L22">22</a></th><td><span class="k">CREATE</span> <span class="k">DATABASE</span> <span class="cm">/*!32312 IF NOT EXISTS*/</span> <span class="o">`</span>app_test<span class="o">`</span> <span class="cm">/*!40100 DEFAULT CHARACTER SET latin1 */</span><span class="p">;</span></td></tr><tr><th id="L23"><a href="#L23">23</a></th><td></td></tr><tr><th id="L24"><a href="#L24">24</a></th><td>USE <span class="o">`</span>app_test<span class="o">`</span><span class="p">;</span></td></tr><tr><th id="L25"><a href="#L25">25</a></th><td></td></tr><tr><th id="L26"><a href="#L26">26</a></th><td><span class="c1">--</span></td></tr><tr><th id="L27"><a href="#L27">27</a></th><td><span class="c1">-- Table structure for table `app_test`</span></td></tr><tr><th id="L28"><a href="#L28">28</a></th><td><span class="c1">--</span></td></tr><tr><th id="L29"><a href="#L29">29</a></th><td><span class="c1"></span></td></tr><tr><th id="L30"><a href="#L30">30</a></th><td><span class="k">DROP</span> <span class="k">TABLE</span> IF <span class="k">EXISTS</span> <span class="o">`</span>app_test<span class="o">`</span><span class="p">;</span></td></tr><tr><th id="L31"><a href="#L31">31</a></th><td><span class="k">CREATE</span> <span class="k">TABLE</span> <span class="o">`</span>app_test<span class="o">`</span> <span class="p">(</span></td></tr><tr><th id="L32"><a href="#L32">32</a></th><td>  <span class="o">`</span>id<span class="o">`</span> <span class="nb">int</span><span class="p">(</span><span class="mi">10</span><span class="p">)</span> unsigned <span class="k">NOT</span> <span class="k">NULL</span> auto_increment<span class="p">,</span></td></tr><tr><th id="L33"><a href="#L33">33</a></th><td>  <span class="o">`</span>name<span class="o">`</span> <span class="nb">varchar</span><span class="p">(</span><span class="mi">255</span><span class="p">)</span> <span class="k">NOT</span> <span class="k">NULL</span><span class="p">,</span></td></tr><tr><th id="L34"><a href="#L34">34</a></th><td>  <span class="o">`</span>value<span class="o">`</span> <span class="nb">text</span> <span class="k">NOT</span> <span class="k">NULL</span><span class="p">,</span></td></tr><tr><th id="L35"><a href="#L35">35</a></th><td>  <span class="k">PRIMARY</span> <span class="k">KEY</span>  <span class="p">(</span><span class="o">`</span>id<span class="o">`</span><span class="p">)</span></td></tr><tr><th id="L36"><a href="#L36">36</a></th><td><span class="p">)</span> ENGINE<span class="o">=</span>InnoDB AUTO_INCREMENT<span class="o">=</span><span class="mi">4</span> <span class="k">DEFAULT</span> CHARSET<span class="o">=</span>latin1<span class="p">;</span></td></tr><tr><th id="L37"><a href="#L37">37</a></th><td></td></tr><tr><th id="L38"><a href="#L38">38</a></th><td><span class="c1">--</span></td></tr><tr><th id="L39"><a href="#L39">39</a></th><td><span class="c1">-- Dumping data for table `app_test`</span></td></tr><tr><th id="L40"><a href="#L40">40</a></th><td><span class="c1">--</span></td></tr><tr><th id="L41"><a href="#L41">41</a></th><td><span class="c1"></span></td></tr><tr><th id="L42"><a href="#L42">42</a></th><td><span class="k">LOCK</span> TABLES <span class="o">`</span>app_test<span class="o">`</span> <span class="k">WRITE</span><span class="p">;</span></td></tr><tr><th id="L43"><a href="#L43">43</a></th><td><span class="cm">/*!40000 ALTER TABLE `app_test` DISABLE KEYS */</span><span class="p">;</span></td></tr><tr><th id="L44"><a href="#L44">44</a></th><td><span class="k">INSERT</span> <span class="k">INTO</span> <span class="o">`</span>app_test<span class="o">`</span> <span class="k">VALUES</span> <span class="p">(</span><span class="mi">1</span><span class="p">,</span><span class="s1">'app_test1'</span><span class="p">,</span><span class="s1">'I am in the db'</span><span class="p">),(</span><span class="mi">2</span><span class="p">,</span><span class="s1">'app_test2'</span><span class="p">,</span><span class="s1">'I am in the db'</span><span class="p">),(</span><span class="mi">3</span><span class="p">,</span><span class="s1">'app_test3'</span><span class="p">,</span><span class="s1">'I am in the db'</span><span class="p">);</span></td></tr><tr><th id="L45"><a href="#L45">45</a></th><td><span class="cm">/*!40000 ALTER TABLE `app_test` ENABLE KEYS */</span><span class="p">;</span></td></tr><tr><th id="L46"><a href="#L46">46</a></th><td>UNLOCK TABLES<span class="p">;</span></td></tr><tr><th id="L47"><a href="#L47">47</a></th><td><span class="cm">/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */</span><span class="p">;</span></td></tr><tr><th id="L48"><a href="#L48">48</a></th><td></td></tr><tr><th id="L49"><a href="#L49">49</a></th><td><span class="cm">/*!40101 SET SQL_MODE=@OLD_SQL_MODE */</span><span class="p">;</span></td></tr><tr><th id="L50"><a href="#L50">50</a></th><td><span class="cm">/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */</span><span class="p">;</span></td></tr><tr><th id="L51"><a href="#L51">51</a></th><td><span class="cm">/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */</span><span class="p">;</span></td></tr><tr><th id="L52"><a href="#L52">52</a></th><td><span class="cm">/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */</span><span class="p">;</span></td></tr><tr><th id="L53"><a href="#L53">53</a></th><td><span class="cm">/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */</span><span class="p">;</span></td></tr><tr><th id="L54"><a href="#L54">54</a></th><td><span class="cm">/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */</span><span class="p">;</span></td></tr><tr><th id="L55"><a href="#L55">55</a></th><td><span class="cm">/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */</span><span class="p">;</span></td></tr><tr><th id="L56"><a href="#L56">56</a></th><td></td></tr><tr><th id="L57"><a href="#L57">57</a></th><td><span class="c1">-- Dump completed on 2010-01-17  4:16:47</span></td></tr></tbody></table>
      </div>
      <div id="help">
        <strong>Note:</strong> See <a href="/trac/rightscale/wiki/TracBrowser">TracBrowser</a>
        for help on using the browser.
      </div>
      <div id="anydiff">
        <form action="/trac/rightscale/diff" method="get">
          <div class="buttons">
            <input type="hidden" name="new_path" value="/unified_test_app/common/sql/app_test.sql" />
            <input type="hidden" name="old_path" value="/unified_test_app/common/sql/app_test.sql" />
            <input type="hidden" name="new_rev" />
            <input type="hidden" name="old_rev" />
            <input type="submit" value="View changes..." title="Select paths and revs for Diff" />
          </div>
        </form>
      </div>
    </div>
    <div id="altlinks">
      <h3>Download in other formats:</h3>
      <ul>
        <li class="first">
          <a rel="nofollow" href="/trac/rightscale/browser/unified_test_app/common/sql/app_test.sql?format=txt">Plain Text</a>
        </li><li class="last">
          <a rel="nofollow" href="/trac/rightscale/export/10588/unified_test_app/common/sql/app_test.sql">Original Format</a>
        </li>
      </ul>
    </div>
    </div>
    <div id="footer" lang="en" xml:lang="en"><hr />
      <a id="tracpowered" href="http://trac.edgewall.org/"><img src="/trac/rightscale/chrome/common/trac_logo_mini.png" height="30" width="107" alt="Trac Powered" /></a>
      <p class="left">
        Powered by <a href="/trac/rightscale/about"><strong>Trac 0.11.7</strong></a><br />
        By <a href="http://www.edgewall.org/">Edgewall Software</a>.
      </p>
      <p class="left">
        Hosted by <a href="http://wush.net/"><strong>WushNet</strong></a><br />
        <a href="http://wush.net/">SVN &amp; Trac Hosting</a>
      </p>
      <p class="right">Visit the Trac open source project at<br /><a href="http://trac.edgewall.com/">http://trac.edgewall.com/</a></p>
    </div>
  </body>
</html>