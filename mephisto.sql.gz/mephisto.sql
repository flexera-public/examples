-- MySQL dump 10.11
--
-- Host: localhost    Database: mephisto_production
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.4-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL auto_increment,
  `content_type` varchar(255) default NULL,
  `filename` varchar(255) default NULL,
  `size` int(11) default NULL,
  `parent_id` int(11) default NULL,
  `thumbnail` varchar(255) default NULL,
  `width` int(11) default NULL,
  `height` int(11) default NULL,
  `site_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `title` varchar(255) default NULL,
  `thumbnails_count` int(11) default '0',
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assigned_assets`
--

DROP TABLE IF EXISTS `assigned_assets`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `assigned_assets` (
  `id` int(11) NOT NULL auto_increment,
  `article_id` int(11) default NULL,
  `asset_id` int(11) default NULL,
  `position` int(11) default NULL,
  `label` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `active` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `assigned_assets`
--

LOCK TABLES `assigned_assets` WRITE;
/*!40000 ALTER TABLE `assigned_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assigned_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assigned_sections`
--

DROP TABLE IF EXISTS `assigned_sections`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `assigned_sections` (
  `id` int(11) NOT NULL auto_increment,
  `article_id` int(11) default NULL,
  `section_id` int(11) default NULL,
  `position` int(11) default '1',
  PRIMARY KEY  (`id`),
  KEY `idx_a_sections_article_section` (`article_id`,`section_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `assigned_sections`
--

LOCK TABLES `assigned_sections` WRITE;
/*!40000 ALTER TABLE `assigned_sections` DISABLE KEYS */;
INSERT INTO `assigned_sections` VALUES (1,1,1,1);
/*!40000 ALTER TABLE `assigned_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cached_pages`
--

DROP TABLE IF EXISTS `cached_pages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cached_pages` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(255) default NULL,
  `references` text,
  `updated_at` datetime default NULL,
  `site_id` int(11) default NULL,
  `cleared_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cached_pages`
--

LOCK TABLES `cached_pages` WRITE;
/*!40000 ALTER TABLE `cached_pages` DISABLE KEYS */;
INSERT INTO `cached_pages` VALUES (1,'/','[1:Article][1:Site][1:User][1:Section]','2009-09-11 21:56:08',1,NULL),(2,'/stylesheets/main.css','','2009-09-11 21:53:54',1,NULL),(3,'/images/bg.png','','2009-09-11 21:53:54',1,NULL),(4,'/images/user.gif','','2009-09-11 21:56:09',1,NULL),(5,'/images/post.gif','','2009-09-11 21:56:09',1,NULL),(6,'/images/packaged.gif','','2009-09-11 21:56:09',1,NULL);
/*!40000 ALTER TABLE `cached_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_versions`
--

DROP TABLE IF EXISTS `content_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `content_versions` (
  `id` int(11) NOT NULL auto_increment,
  `content_id` int(11) default NULL,
  `version` int(11) default NULL,
  `article_id` int(11) default NULL,
  `user_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `permalink` varchar(255) default NULL,
  `excerpt` text,
  `body` text,
  `excerpt_html` text,
  `body_html` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `published_at` datetime default NULL,
  `author` varchar(100) default NULL,
  `author_url` varchar(255) default NULL,
  `author_email` varchar(255) default NULL,
  `author_ip` varchar(100) default NULL,
  `comments_count` int(11) default '0',
  `updater_id` int(11) default NULL,
  `versioned_type` varchar(20) default NULL,
  `site_id` int(11) default NULL,
  `approved` tinyint(1) default '0',
  `comment_age` int(11) default '0',
  `filter` varchar(255) default NULL,
  `user_agent` varchar(255) default NULL,
  `referrer` varchar(255) default NULL,
  `assets_count` int(11) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `content_versions`
--

LOCK TABLES `content_versions` WRITE;
/*!40000 ALTER TABLE `content_versions` DISABLE KEYS */;
INSERT INTO `content_versions` VALUES (1,NULL,1,1,1,'RightScale Rocks!','rightscale-rocks','','Congratulations you have successfully configured a mephisto server on the cloud using the RightScale platform!!','','<p>Congratulations you have successfully configured a mephisto server on the cloud using the RightScale platform!!</p>','2009-09-11 21:56:01','2009-09-11 21:56:01','2009-09-11 21:54:00',NULL,NULL,NULL,NULL,0,1,'Article',1,0,30,'textile_filter',NULL,NULL,0);
/*!40000 ALTER TABLE `content_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contents`
--

DROP TABLE IF EXISTS `contents`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `contents` (
  `id` int(11) NOT NULL auto_increment,
  `article_id` int(11) default NULL,
  `user_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `permalink` varchar(255) default NULL,
  `excerpt` text,
  `body` text,
  `excerpt_html` text,
  `body_html` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `published_at` datetime default NULL,
  `type` varchar(20) default NULL,
  `author` varchar(100) default NULL,
  `author_url` varchar(255) default NULL,
  `author_email` varchar(255) default NULL,
  `author_ip` varchar(100) default NULL,
  `comments_count` int(11) default '0',
  `updater_id` int(11) default NULL,
  `version` int(11) default NULL,
  `site_id` int(11) default NULL,
  `approved` tinyint(1) default '0',
  `comment_age` int(11) default '0',
  `filter` varchar(255) default NULL,
  `user_agent` varchar(255) default NULL,
  `referrer` varchar(255) default NULL,
  `assets_count` int(11) default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_comments` (`article_id`,`approved`,`type`),
  KEY `idx_articles_published` (`published_at`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `contents`
--

LOCK TABLES `contents` WRITE;
/*!40000 ALTER TABLE `contents` DISABLE KEYS */;
INSERT INTO `contents` VALUES (1,NULL,1,'RightScale Rocks!','rightscale-rocks','','Congratulations you have successfully configured a mephisto server on the cloud using the RightScale platform!!','','<p>Congratulations you have successfully configured a mephisto server on the cloud using the RightScale platform!!</p>','2009-09-11 21:56:01','2009-09-11 21:56:01','2009-09-11 21:54:00','Article',NULL,NULL,NULL,NULL,0,1,1,1,0,30,'textile_filter',NULL,NULL,0);
/*!40000 ALTER TABLE `contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `events` (
  `id` int(11) NOT NULL auto_increment,
  `mode` varchar(255) default NULL,
  `user_id` int(11) default NULL,
  `article_id` int(11) default NULL,
  `title` text,
  `body` text,
  `created_at` datetime default NULL,
  `author` varchar(100) default NULL,
  `comment_id` int(11) default NULL,
  `site_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'publish',1,1,'RightScale Rocks!','Congratulations you have successfully configured a mephisto server on the cloud using the RightScale platform!!','2009-09-11 21:56:01',NULL,NULL,1);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedbacks`
--

DROP TABLE IF EXISTS `feedbacks`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL auto_increment,
  `site_id` int(11) default NULL,
  `name` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `body` text,
  `key` varchar(255) default NULL,
  `created_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `feedbacks`
--

LOCK TABLES `feedbacks` WRITE;
/*!40000 ALTER TABLE `feedbacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedbacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberships`
--

DROP TABLE IF EXISTS `memberships`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `memberships` (
  `id` int(11) NOT NULL auto_increment,
  `site_id` int(11) default NULL,
  `user_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `admin` tinyint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `memberships`
--

LOCK TABLES `memberships` WRITE;
/*!40000 ALTER TABLE `memberships` DISABLE KEYS */;
/*!40000 ALTER TABLE `memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mephisto_plugins`
--

DROP TABLE IF EXISTS `mephisto_plugins`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mephisto_plugins` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `options` text,
  `type` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mephisto_plugins`
--

LOCK TABLES `mephisto_plugins` WRITE;
/*!40000 ALTER TABLE `mephisto_plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `mephisto_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('1'),('10'),('11'),('12'),('13'),('14'),('15'),('16'),('17'),('18'),('19'),('2'),('20'),('20081219130711'),('20081223142853'),('20081223221228'),('21'),('22'),('23'),('24'),('25'),('26'),('27'),('28'),('29'),('3'),('30'),('31'),('32'),('33'),('34'),('35'),('36'),('37'),('38'),('39'),('4'),('40'),('41'),('42'),('43'),('44'),('45'),('46'),('47'),('48'),('49'),('5'),('50'),('51'),('52'),('53'),('54'),('55'),('56'),('57'),('58'),('59'),('6'),('60'),('61'),('62'),('63'),('64'),('65'),('66'),('67'),('68'),('69'),('7'),('70'),('71'),('72'),('73'),('74'),('75'),('76'),('8'),('9');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `show_paged_articles` tinyint(1) default '0',
  `articles_per_page` int(11) default '15',
  `layout` varchar(255) default NULL,
  `template` varchar(255) default NULL,
  `site_id` int(11) default NULL,
  `path` varchar(255) default NULL,
  `articles_count` int(11) default '0',
  `archive_path` varchar(255) default NULL,
  `archive_template` varchar(255) default NULL,
  `position` int(11) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,'Home',0,15,NULL,'home.liquid',1,'',1,'archives',NULL,1);
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) default NULL,
  `subtitle` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `ping_urls` text,
  `articles_per_page` int(11) default '15',
  `host` varchar(255) default NULL,
  `approve_comments` tinyint(1) default NULL,
  `comment_age` int(11) default NULL,
  `timezone` varchar(255) default NULL,
  `filter` varchar(255) default 'textile_filter',
  `permalink_style` varchar(255) default NULL,
  `search_path` varchar(255) default NULL,
  `tag_path` varchar(255) default NULL,
  `tag_layout` varchar(255) default NULL,
  `current_theme_path` varchar(255) default NULL,
  `akismet_key` varchar(100) default NULL,
  `akismet_url` varchar(255) default NULL,
  `lang` varchar(255) NOT NULL default 'en-US',
  PRIMARY KEY  (`id`),
  KEY `index_sites_on_host` (`host`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,'Mephisto','Publish With Impunity','email@domain.com',NULL,15,'unusedfornow.com',1,30,'UTC','textile_filter',':year/:month/:day/:permalink','search','tags',NULL,'simpla',NULL,NULL,'en-US');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggings`
--

DROP TABLE IF EXISTS `taggings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `taggings` (
  `id` int(11) NOT NULL auto_increment,
  `tag_id` int(11) default NULL,
  `taggable_id` int(11) default NULL,
  `taggable_type` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `taggings`
--

LOCK TABLES `taggings` WRITE;
/*!40000 ALTER TABLE `taggings` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(40) default NULL,
  `email` varchar(100) default NULL,
  `crypted_password` varchar(40) default NULL,
  `salt` varchar(40) default NULL,
  `activation_code` varchar(40) default NULL,
  `activated_at` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted_at` datetime default NULL,
  `token` varchar(255) default NULL,
  `token_expires_at` datetime default NULL,
  `filter` varchar(255) default 'textile_filter',
  `admin` tinyint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@changeme.com','00742970dc9e6319f8019fd54864d3ea740f04b1','7e3041ebc2fc05a40c60028e2c4901a81035d3cd',NULL,'2009-09-11 21:47:13','2009-09-11 21:47:13','2009-09-11 21:47:13',NULL,NULL,NULL,'textile_filter',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-09-11 22:06:32
